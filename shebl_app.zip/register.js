firebase.auth().createUserWithEmailAndPassword(email, password)
    .then((userCredential) => {
        let userId = userCredential.user.uid;
        let userData = { name, email, userType };
        if (userType === "doctor") {
            let certificate = document.getElementById("certificate").files[0];
            if (certificate) {
                let storageRef = firebase.storage().ref('certificates/' + userId);
                storageRef.put(certificate).then(() => {
                    userData.certificateUploaded = true;
                    firebase.database().ref('users/' + userId).set(userData);
                });
            }
        } else {
            firebase.database().ref('users/' + userId).set(userData);
        }
        alert("تم إنشاء الحساب بنجاح!");
        window.location.href = "index.html";
    })
    .catch(error => alert(error.message));