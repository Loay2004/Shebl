firebase.auth().signInWithEmailAndPassword(email, password)
    .then((userCredential) => {
        let user = userCredential.user;
        firebase.database().ref('users/' + user.uid).once('value', (snapshot) => {
            let userData = snapshot.val();
            if (userData.userType === 'doctor') {
                window.location.href = "doctor-dashboard.html";
            } else {
                window.location.href = "patient-dashboard.html";
            }
        });
    })
    .catch(error => alert(error.message));